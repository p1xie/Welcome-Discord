# Discord.Net v0.9.6
[![NuGet Pre Release](https://img.shields.io/nuget/vpre/Discord.Net.svg?maxAge=2592000?style=plastic)](https://www.nuget.org/packages/Discord.Net) [![Discord](https://discordapp.com/api/guilds/81384788765712384/widget.png)](https://discord.gg/0SBTUU1wZTYLhAAW)

An unofficial .Net API Wrapper for the Discord client (http://discordapp.com).

Check out the [documentation](http://rtd.discord.foxbot.me/en/legacy/) or join the [Discord API Chat](https://discord.gg/discord-api).

### Installation
You can download Discord.Net and its extensions from NuGet:
- [Discord.Net](https://www.nuget.org/packages/Discord.Net/)
- [Discord.Net.Commands](https://www.nuget.org/packages/Discord.Net.Commands/)
- [Discord.Net.Modules](https://www.nuget.org/packages/Discord.Net.Modules/)
- [Discord.Net.Audio](https://www.nuget.org/packages/Discord.Net.Audio/)

### Compiling
In order to compile Discord.Net, you require at least the following:
- [Visual Studio 2015](https://www.visualstudio.com/downloads/download-visual-studio-vs)
- [Visual Studio 2015 Update 3](https://www.microsoft.com/net/core#windows)
- [Visual Studio .Net Core Plugin](https://www.microsoft.com/net/core#windows)
- NuGet 3.3+ (available through Visual Studio)
