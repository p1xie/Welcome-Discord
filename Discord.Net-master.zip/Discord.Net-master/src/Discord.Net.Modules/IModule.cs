﻿namespace Discord.Modules
{
    public interface IModule
	{
		void Install(ModuleManager manager);
	}
}
