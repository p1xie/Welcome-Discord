﻿namespace Discord
{
    public interface IService
    {
        void Install(DiscordClient client);
    }
}
