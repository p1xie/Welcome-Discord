﻿namespace Discord
{
	public enum ImageType
	{
		None,
		Jpeg,
		Png
	}
}
