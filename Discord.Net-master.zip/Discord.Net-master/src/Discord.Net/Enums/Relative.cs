﻿namespace Discord
{
    public enum Relative
    {
        Before, After, Around
    }
}
