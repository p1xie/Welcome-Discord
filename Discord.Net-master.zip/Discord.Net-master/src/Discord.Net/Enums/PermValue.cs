﻿namespace Discord
{
    public enum PermValue
    {
        Allow,
        Deny,
        Inherit
    }
}
