﻿namespace Discord
{
    public enum TokenType
    {
        User,
        Bot,
    }
}
