﻿namespace Discord
{
    public enum GameType : int
    {
        Default = 0,   // "NotStreaming", pretty much
        Twitch
    }
}
