﻿namespace Discord.API.Client.GatewaySocket.Events
{
    //public class GuildEmojisUpdateEvent { }
}
