﻿namespace Discord.API.Client.GatewaySocket
{
    public class ChannelUpdateEvent : Channel { }
}
