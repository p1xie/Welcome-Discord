﻿namespace Discord.API.Client.GatewaySocket
{
    public class GuildDeleteEvent : ExtendedGuild { }
}
