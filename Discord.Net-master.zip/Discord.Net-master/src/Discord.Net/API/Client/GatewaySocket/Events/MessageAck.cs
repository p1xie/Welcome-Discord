﻿namespace Discord.API.Client.GatewaySocket
{
    public class MessageAckEvent : MessageReference { }
}
