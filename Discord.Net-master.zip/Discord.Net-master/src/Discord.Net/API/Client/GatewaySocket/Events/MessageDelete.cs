﻿namespace Discord.API.Client.GatewaySocket
{
    public class MessageDeleteEvent : MessageReference { }
}
