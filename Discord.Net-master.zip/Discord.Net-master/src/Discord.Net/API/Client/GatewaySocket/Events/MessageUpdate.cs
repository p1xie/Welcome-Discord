﻿namespace Discord.API.Client.GatewaySocket
{
    public class MessageUpdateEvent : Message { }
}
