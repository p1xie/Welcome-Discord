﻿namespace Discord.API.Client.GatewaySocket
{
    public class VoiceStateUpdateEvent : MemberVoiceState { }
}
