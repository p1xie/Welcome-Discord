﻿namespace Discord.API.Client.GatewaySocket
{
    public class GuildCreateEvent : ExtendedGuild { }
}
