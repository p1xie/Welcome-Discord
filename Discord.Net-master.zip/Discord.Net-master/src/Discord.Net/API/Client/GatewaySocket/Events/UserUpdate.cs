﻿namespace Discord.API.Client.GatewaySocket
{
    public class UserUpdateEvent : User { }
}
