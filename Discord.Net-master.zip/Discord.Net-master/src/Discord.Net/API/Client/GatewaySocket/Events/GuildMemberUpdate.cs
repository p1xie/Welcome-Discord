﻿namespace Discord.API.Client.GatewaySocket
{
    public class GuildMemberUpdateEvent : Member { }
}
