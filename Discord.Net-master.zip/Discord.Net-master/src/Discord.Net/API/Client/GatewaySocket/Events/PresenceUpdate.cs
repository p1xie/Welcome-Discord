﻿namespace Discord.API.Client.GatewaySocket
{
    public class PresenceUpdateEvent : MemberPresence { }
}
