﻿namespace Discord.API.Client.GatewaySocket
{
    public class GuildMemberAddEvent : ExtendedMember { }
}
