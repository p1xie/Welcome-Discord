﻿using Newtonsoft.Json;

namespace Discord.API.Client.GatewaySocket
{
    public class ReconnectEvent { }
}
