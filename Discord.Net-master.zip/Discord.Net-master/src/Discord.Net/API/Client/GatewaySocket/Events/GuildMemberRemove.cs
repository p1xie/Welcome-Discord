﻿namespace Discord.API.Client.GatewaySocket
{
    public class GuildMemberRemoveEvent : Member { }
}
