﻿namespace Discord.API.Client.GatewaySocket
{
	public class ChannelCreateEvent : Channel { }
}
