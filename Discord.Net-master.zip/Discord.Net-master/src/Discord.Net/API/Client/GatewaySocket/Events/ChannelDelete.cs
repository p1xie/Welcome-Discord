﻿namespace Discord.API.Client.GatewaySocket
{
    public class ChannelDeleteEvent : Channel { }
}
