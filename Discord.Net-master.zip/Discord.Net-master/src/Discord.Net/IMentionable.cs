﻿namespace Discord
{
    public interface IMentionable
    {
        string Mention { get; }
    }
}
